import 'package:flutter/material.dart';

class WorkOrderForm extends StatefulWidget {
  @override
  _WorkOrderFormState createState() => _WorkOrderFormState();
}

class _WorkOrderFormState extends State<WorkOrderForm> {
  final _formKey2 = GlobalKey();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //resizeToAvoidBottomPadding:false,
      appBar: AppBar(
        actions: <Widget>[
          Icon(Icons.work),
        ],
        centerTitle: true,
        title: Text("Work Order  Request Form"),
      ),
      body: ListView(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(10),
            // height: MediaQuery.of(context).size.height,
            child: Column(
              children: <Widget>[
                Container(
                  height: 50,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                      // color: Colors.lightBlue,
                      border: Border.all(style: BorderStyle.solid)),
                  child: Form(
                    key: _formKey2,
                    child: Column(
                      children: <Widget>[

                        Flexible(
                            child: Container(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                              "CENTRAL BANK OF NIGERIA  ABUJA \n REGISCOPE SYSTEMS MAINTENANCE REPORT"),
                        ))
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 20),
                TextFormField(
                  keyboardType: TextInputType.numberWithOptions(),
                  decoration: InputDecoration(
                    hintText: ('mm/dd/yyyy'),
                    labelText: "Date",
                    border: OutlineInputBorder(
                        borderRadius:
                            BorderRadius.all(new Radius.circular(2.0))),
                  ),
                ),
                SizedBox(height: 20),
                TextFormField(
                  maxLines: 3,
                  decoration: InputDecoration(
                    // prefixText:"Prefixtext" ,
                    // helperText: "Helper TExt",
                    alignLabelWithHint: true,
                    // prefixText: "Name:",
                    labelText: "ACTION TAKEN",
                    border: OutlineInputBorder(
                        borderRadius:
                            BorderRadius.all(new Radius.circular(2.0))),
                  ),
                ),
                SizedBox(height: 20),
                TextFormField(
                  maxLines: 3,
                  decoration: InputDecoration(
                    // prefixText:"Prefixtext" ,
                    // helperText: "Helper TExt",
                    alignLabelWithHint: true,
                    // prefixText: "Name:",
                    labelText: "COMPONENTS MAINTAINED",
                    border: OutlineInputBorder(
                        borderRadius:
                            BorderRadius.all(new Radius.circular(2.0))),
                  ),
                ),
                SizedBox(height: 20),
                TextFormField(
                  maxLines: 3,
                  decoration: InputDecoration(
                    // prefixText:"Prefixtext" ,
                    // helperText: "Helper TExt",
                    alignLabelWithHint: true,
                    // prefixText: "Name:",
                    labelText: "ENGINEERS REMARKS",
                    border: OutlineInputBorder(
                        borderRadius:
                            BorderRadius.all(new Radius.circular(2.0))),
                  ),
                ),
                SizedBox(height: 20),
                _buildRow2(),
                SizedBox(height: 20),
                TextFormField(
                  maxLines: 3,
                  decoration: InputDecoration(
                    // prefixText:"Prefixtext" ,
                    // helperText: "Helper TExt",
                    alignLabelWithHint: true,
                    // prefixText: "Name:",
                    labelText: "CLIENT'S REMARK",
                    border: OutlineInputBorder(
                        borderRadius:
                            BorderRadius.all(new Radius.circular(2.0))),
                  ),
                ),
                SizedBox(height: 20),
                _buildRow3(),
                SizedBox(height: 10),
                Text("Signature"),
                Container(
                  // child: Text("Signature"),
                  height: 100,
                  decoration: BoxDecoration(
                    border: Border.all(width: 2, style: BorderStyle.solid),
                  ),
                ),
                SizedBox(height: 10),
                RaisedButton(
                    color: Colors.deepPurple,
                    child: Text(
                      "Submit",
                      style: TextStyle(color: Colors.white),
                    ),
                    onPressed: () {
                      sendFormData2Email();
                      
                    })
              ],
            ),
          ),
        ],
      ),
    );
  }

  Row _buildRow2() {
    return Row(
      // mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        // SizedBox(width: 10),
        Flexible(
          child: TextFormField(
            // maxLength: 50,
            decoration: InputDecoration(
              labelText: "Engrs Name",
              // prefixText: "Office:",
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(new Radius.circular(2.0))),
            ),
          ),
        ),
        SizedBox(width: 8),
        Flexible(
          child: TextFormField(
            // maxLength: 50,
            decoration: InputDecoration(
              labelText: "Engrs Signature",
              // prefixText: "Office:",
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(new Radius.circular(2.0))),
            ),
          ),
        ),
      ],
    );
  }

  Row _buildRow3() {
    return Row(
      // mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        // SizedBox(width: 10),
        Flexible(
          child: TextFormField(
            // maxLength: 50,
            decoration: InputDecoration(
              labelText: "Client's Name",
              // prefixText: "Office:",
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(new Radius.circular(2.0))),
            ),
          ),
        ),
        SizedBox(width: 8),
        Flexible(
          child: TextFormField(
            // maxLength: 50,
            decoration: InputDecoration(
              labelText: "Office",
              // prefixText: "Office:",
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(new Radius.circular(2.0))),
            ),
          ),
        ),
      ],
    );
  }

  void sendFormData2Email() {}
}
